PROJECT WARRIORS — REVISION 4 DELTA CONSOLIDATION PACKAGE
Generated: 2026-04-18
Version: rev4
Base dependency: apply after / on top of PW Revision 3 consolidation package dated 2026-04-14.

PURPOSE
This package is a delta-style source consolidation package for material visible in the Project Warriors workspace and project-thread context after the Revision 3 consolidation package, plus a small number of clearly visible locks that were not fully represented in the rev3 files.

This package intentionally does not re-export the complete rev3 corpus. It is designed as the second successive patch after rev3, so the branch order should be:
1. merge/apply rev3 consolidation package
2. merge/apply this rev4 delta package

PACKAGE CONTENTS
- one rev4 delta archival master
- six rev4 working-compendium delta files
- one rev4 memory integration patch
- one rev4 migration ledger
- one rev4 thread archive / migration audit
- one rev4 source manifest CSV
- one rev4 package changelog
- one rev4 recommended upload-order note
- one rev4 consolidation report
- one rev4 PR packet

SCOPE NOTE
This package is based on accessible workspace files, the rev3 package present in /mnt/data, project memory available in this conversation, visible project-thread summaries, and retrievable personal project context. It cannot prove that every external GitHub-only file or hidden/generated image asset has been reconciled.

USE RULE
Treat these files as patch files, not wholesale replacements for the rev3 compendia unless your repo-side source layout prefers milestone replacement documents. Where a delta file says PARTIAL / CHECK SOURCE, verify the corresponding repo-side thread output before retiring that thread or deleting older source notes.
